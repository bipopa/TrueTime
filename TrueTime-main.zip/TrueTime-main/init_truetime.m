cd kernel
setenv('TTKERNEL',pwd)
cd matlab
cd help
addpath(pwd)
cd ..
addpath(pwd)
cd ..
addpath(pwd)
cd ..
